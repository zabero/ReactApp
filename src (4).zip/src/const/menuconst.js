export const Translations = {
  m1: "Masaż klasyczny tajksi",
};

export const Booking = () => {
    return (
        <div>Um�w wizyt�</div>
    )
}
export const Voucher = () => {
    return (
        <div>Vouhcery</div>
    )
}
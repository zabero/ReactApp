export const NotFound = () => {
    return (
        <div>Not Found </div>
    )
}